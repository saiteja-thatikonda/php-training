<html>
<body>
<center>
<form action="submit.php" method="post">

Name: <input type="text" name="name" required ="required" ><br>
E-mail: <input type="text" name="email" required ="required"><br>
Mobile Number: <input type="text" name="mobilenumber" required ="required"><br>
<input type="submit">
</form>
</center>
</body>
</html>

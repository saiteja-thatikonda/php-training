<!DOCTYPE html>
<html>
<body>

<?php
$x = 100;
$y = 80;
$z= 70;

if ($x == 10 and $y == 60) {
    echo "Hello world!";
}
elseif($y == 60 and $z!=90){
    echo "bye";

}

else{
echo "gud";
}
?>




</body>
</html>

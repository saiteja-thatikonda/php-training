<!DOCTYPE html>
<html>
<body>


<p>include </p>
<p>require </p>
<?php include 'form.php';?>

</body>
</html>

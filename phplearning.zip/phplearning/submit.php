<html>
<body>

Welcome <?php echo $_POST["name"]; ?><br>
Your email address is: <?php echo $_POST["email"]; ?><br>
mobile number : <?php echo $_POST["mobilenumber"]; ?>
</body>
</html>

<!DOCTYPE html>
<html>
<body>

<h1>My first PHP page</h1>

<?php

$color = "red";
echo "My car is " . $color . "<br>";
echo "My house is " . $COLOR . "<br>";
echo "Hello World!";
?>


</body>
</html>
